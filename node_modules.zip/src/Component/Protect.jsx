import React from 'react'

const Protect = () => {
    let user=sessionStorage.getItem("user")
  return (
    <div>

    </div>
  )
}

export default Protect